"""Optimizer stubs (e.g., CEM) for Chapter 7."""

__all__: list[str] = []
