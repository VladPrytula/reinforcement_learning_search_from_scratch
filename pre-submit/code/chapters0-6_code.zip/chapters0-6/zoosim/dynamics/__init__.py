"""User dynamics and rewards (Chapters 2 + 5)."""

from . import behavior, reward

__all__ = ["behavior", "reward"]
