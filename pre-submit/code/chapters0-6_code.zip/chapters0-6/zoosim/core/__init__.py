"""Core simulator objects shared across Part II (Chapter 4 onwards)."""

from . import config

__all__ = ["config"]
