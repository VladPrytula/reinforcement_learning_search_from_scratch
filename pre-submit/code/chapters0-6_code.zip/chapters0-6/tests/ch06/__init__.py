"""Tests for Chapter 6: Discrete Template Bandits."""
