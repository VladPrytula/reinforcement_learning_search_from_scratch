"""Chapter 5 tests: relevance, features, and reward."""

