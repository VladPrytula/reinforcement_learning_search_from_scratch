#!/usr/bin/env python
"""Chapter 6 demonstration: Template bandits vs static baselines.

This script instantiates the Zoosim world (catalog, users, queries) and
compares:

- Static templates: each BoostTemplate applied greedily every episode
- LinUCB contextual bandit over templates
- Thompson Sampling contextual bandit over templates

The reward is the scalar multi-objective reward from Chapter 5
(#EQ-1.2 / #EQ-5.7), and we log GMV / CM2 averages to see how much
uplift the template bandits achieve relative to static baselines.

Run with:

    python scripts/ch06/template_bandits_demo.py
    python scripts/ch06/template_bandits_demo.py --n-episodes 20000
    python scripts/ch06/template_bandits_demo.py --n-static 4000 --n-bandit 2000

CLI parameters:
- ``--n-episodes``: total episode count used for both static and bandit sections (default 5,000 if neither per‑section flag is set).
- ``--n-static``: episode count for static template baselines only; overrides ``--n-episodes`` for the static part (Chapter 6 §6.5/§6.7 tables).
- ``--n-bandit``: episode count for LinUCB / Thompson Sampling runs; overrides ``--n-episodes`` for the bandit part.
- ``--features``: context feature mode for the bandits:
    - ``simple`` → 7‑dim features (segment + query type), used in §6.5 to show the failure (−30 % / −10 % GMV vs static).
    - ``rich`` → 17‑dim features (segment + query + oracle user latents + base‑top‑K aggregates), used in §6.7 to show the rich‑feature fix (+3 % / +27 % GMV).
    - ``rich_est`` → same structure as ``rich`` but with *estimated* user latents (for labs/experiments beyond the core narrative).
- ``--show-volume``: if set, also prints average order volume per policy and segment, exposing the “GMV vs Orders” trade‑off discussed in §6.7 and the labs.

Notes:
- This is a lightweight demonstration, not a full acceptance test.
- Defaults use 5,000 episodes for both static and bandit sections; override via CLI.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import numpy as np

from zoosim.core.config import SimulatorConfig
from zoosim.dynamics import behavior, reward
from zoosim.policies.lin_ucb import LinUCB, LinUCBConfig
from zoosim.policies.templates import BoostTemplate, compute_catalog_stats, create_standard_templates
from zoosim.policies.thompson_sampling import LinearThompsonSampling, ThompsonSamplingConfig
from zoosim.ranking.features import (
    compute_context_features_simple,
    compute_context_features_rich,
    compute_context_features_rich_estimated,
)
from zoosim.world import catalog as catalog_module
from zoosim.world.catalog import Product
from zoosim.world.queries import Query, sample_query
from zoosim.world.users import User, sample_user

DEFAULT_EPISODES = 5_000


@dataclass
class EpisodeResult:
    reward: float
    gmv: float
    cm2: float
    orders: float


# ---------------------------------------------------------------------------
# Feature extraction functions now imported from zoosim.ranking.features
# See imports above for: compute_context_features_simple,
#                        compute_context_features_rich,
#                        compute_context_features_rich_estimated
# ---------------------------------------------------------------------------


def _progress(prefix: str, step: int, total: int, extra: str = "") -> None:
    """Lightweight textual progress indicator (newline per update)."""
    pct = 100.0 * step / max(total, 1)
    message = f"{prefix}: {pct:5.1f}% ({step}/{total})"
    if extra:
        message += f" | {extra}"
    print(message)


def _simulate_episode_for_template(
    *,
    template: BoostTemplate,
    cfg: SimulatorConfig,
    user: User,
    query: Query,
    products,
    rng: np.random.Generator,
    base_scores: np.ndarray | None = None,
) -> EpisodeResult:
    """Simulate a single episode under a fixed template.

    The ranking logic mirrors zoosim.envs.search_env and multi_episode.session_env:
    - Compute base relevance scores
    - Add template boosts
    - Sort to obtain ranking
    - Simulate session and compute reward / breakdown
    """
    from zoosim.ranking import relevance  # Imported here to avoid cycles at import time

    if base_scores is None:
        base_scores = np.asarray(
            relevance.batch_base_scores(
                query=query,
                catalog=products,
                config=cfg,
                rng=rng,
            ),
            dtype=float,
        )
    else:
        base_scores = np.asarray(base_scores, dtype=float)

    boosts = template.apply(products)
    blended = base_scores + boosts
    ranking = np.argsort(-blended).tolist()

    outcome = behavior.simulate_session(
        user=user,
        query=query,
        ranking=ranking,
        catalog=products,
        config=cfg,
        rng=rng,
    )
    reward_value, breakdown = reward.compute_reward(
        ranking=ranking,
        clicks=outcome.clicks,
        buys=outcome.buys,
        catalog=products,
        config=cfg,
    )
    orders = float(sum(outcome.buys))
    return EpisodeResult(
        reward=float(reward_value),
        gmv=breakdown.gmv,
        cm2=breakdown.cm2,
        orders=orders,
    )


def _run_static_templates(
    *,
    cfg: SimulatorConfig,
    products,
    templates: List[BoostTemplate],
    n_episodes: int,
    seed: int,
) -> Dict[int, EpisodeResult]:
    """Evaluate each template as a static policy over n_episodes."""
    from zoosim.ranking import relevance

    rng = np.random.default_rng(seed)
    totals: Dict[int, Tuple[float, float, float, float]] = {
        t.id: (0.0, 0.0, 0.0, 0.0) for t in templates
    }

    progress_interval = max(1, n_episodes // 50)  # 2% increments

    for episode_idx in range(1, n_episodes + 1):
        user = sample_user(config=cfg, rng=rng)
        query = sample_query(user=user, config=cfg, rng=rng)

        base_scores = np.asarray(
            relevance.batch_base_scores(
                query=query,
                catalog=products,
                config=cfg,
                rng=rng,
            ),
            dtype=float,
        )

        for template in templates:
            key = template.id
            episode = _simulate_episode_for_template(
                template=template,
                cfg=cfg,
                user=user,
                query=query,
                products=products,
                rng=rng,
                base_scores=base_scores,
            )
            r_sum, g_sum, c_sum, o_sum = totals[key]
            totals[key] = (
                r_sum + episode.reward,
                g_sum + episode.gmv,
                c_sum + episode.cm2,
                o_sum + episode.orders,
            )
        if (
            episode_idx == 1
            or episode_idx % progress_interval == 0
            or episode_idx == n_episodes
        ):
            # Compute provisional best template average reward
            best_template_id = max(
                totals,
                key=lambda key: totals[key][0] / episode_idx if episode_idx > 0 else 0.0,
            )
            best_template_avg = totals[best_template_id][0] / episode_idx
            extra = (
                f"best template ID {best_template_id} avg reward {best_template_avg:,.2f}"
            )
            _progress("  Static templates progress", episode_idx, n_episodes, extra)

    print("")  # newline after progress

    results: Dict[int, EpisodeResult] = {}
    for template in templates:
        r_sum, g_sum, c_sum, o_sum = totals[template.id]
        results[template.id] = EpisodeResult(
            reward=r_sum / n_episodes,
            gmv=g_sum / n_episodes,
            cm2=c_sum / n_episodes,
            orders=o_sum / n_episodes,
        )
    return results


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Chapter 6 template bandits demonstration."
    )
    parser.add_argument(
        "--n-episodes",
        type=int,
        default=None,
        help="Episode count for both static and bandit sections.",
    )
    parser.add_argument(
        "--n-static",
        type=int,
        default=None,
        help="Episodes for static template baselines (overrides --n-episodes).",
    )
    parser.add_argument(
        "--n-bandit",
        type=int,
        default=None,
        help="Episodes for LinUCB/TS runs (overrides --n-episodes).",
    )
    parser.add_argument(
        "--show-volume",
        action="store_true",
        help="Print order/volume metrics alongside Reward/GMV/CM2.",
    )
    parser.add_argument(
        "--features",
        type=str,
        choices=["simple", "rich", "rich_est"],
        default="simple",
        help=(
            "Feature mode for contextual bandits: "
            "'simple' (segment+query), 'rich' (oracle user latents + aggregates), "
            "or 'rich_est' (approximate user latents + aggregates). "
            "Default 'simple' emphasizes the failure mode."
        ),
    )
    return parser.parse_args()


def _run_bandit_policy(
    *,
    cfg: SimulatorConfig,
    products,
    templates: List[BoostTemplate],
    n_episodes: int,
    seed: int,
    policy_type: str = "linucb",
    feature_mode: str = "simple",
) -> Tuple[EpisodeResult, Dict[str, EpisodeResult], Dict[str, Any]]:
    """Run a contextual bandit over templates for n_episodes.

    Returns:
        global_result: EpisodeResult averaged over all episodes
        segment_results: Mapping user_segment -> EpisodeResult averaged
                         over episodes where that segment appeared.
    """
    from zoosim.ranking import relevance

    rng = np.random.default_rng(seed)

    if feature_mode == "simple":
        d = len(cfg.users.segments) + len(cfg.queries.query_types)
    elif feature_mode in ("rich", "rich_est"):
        d = (
            len(cfg.users.segments)
            + len(cfg.queries.query_types)
            + 2  # user preference proxies
            + 8  # aggregates from base top-k
        )
    else:
        raise ValueError(f"Unknown feature_mode: {feature_mode}")

    if policy_type == "linucb":
        policy = LinUCB(
            templates=templates,
            feature_dim=d,
            config=LinUCBConfig(lambda_reg=1.0, alpha=1.0, adaptive_alpha=True, seed=seed),
        )
    elif policy_type == "ts":
        policy = LinearThompsonSampling(
            templates=templates,
            feature_dim=d,
            config=ThompsonSamplingConfig(lambda_reg=1.0, sigma_noise=1.0, seed=seed),
        )
    else:
        raise ValueError(f"Unknown policy_type: {policy_type}")

    reward_total = 0.0
    gmv_total = 0.0
    cm2_total = 0.0
    orders_total = 0.0

    # Per-segment aggregates: segment -> (sum_reward, sum_gmv, sum_cm2, sum_orders, count)
    seg_totals: Dict[str, Tuple[float, float, float, float, int]] = {}
    template_counts = np.zeros(len(templates), dtype=int)

    progress_interval = max(1, n_episodes // 50)

    for episode_idx in range(1, n_episodes + 1):
        user = sample_user(config=cfg, rng=rng)
        query = sample_query(user=user, config=cfg, rng=rng)

        base_scores = np.asarray(
            relevance.batch_base_scores(
                query=query,
                catalog=products,
                config=cfg,
                rng=rng,
            ),
            dtype=float,
        )

        if feature_mode == "simple":
            phi = compute_context_features_simple(user, query, cfg)
        elif feature_mode == "rich":
            phi = compute_context_features_rich(user, query, products, base_scores, cfg)
        elif feature_mode == "rich_est":
            phi = compute_context_features_rich_estimated(
                user,
                query,
                products,
                base_scores,
                cfg,
            )
        else:
            raise ValueError(f"Unknown feature_mode: {feature_mode}")

        action = policy.select_action(phi.astype(np.float64))
        template_counts[action] += 1

        episode = _simulate_episode_for_template(
            template=templates[action],
            cfg=cfg,
            user=user,
            query=query,
            products=products,
            rng=rng,
            base_scores=base_scores,
        )

        policy.update(
            action=action,
            features=phi.astype(np.float64),
            reward=episode.reward,
        )

        reward_total += episode.reward
        gmv_total += episode.gmv
        cm2_total += episode.cm2
        orders_total += episode.orders

        seg_key = user.segment
        s_r, s_g, s_c, s_o, s_n = seg_totals.get(seg_key, (0.0, 0.0, 0.0, 0.0, 0))
        seg_totals[seg_key] = (
            s_r + episode.reward,
            s_g + episode.gmv,
            s_c + episode.cm2,
            s_o + episode.orders,
            s_n + 1,
        )
        if (
            episode_idx == 1
            or episode_idx % progress_interval == 0
            or episode_idx == n_episodes
        ):
            avg_reward = reward_total / episode_idx
            extra = f"avg reward {avg_reward:,.2f}"
            _progress(f"  {policy_type.upper()} progress", episode_idx, n_episodes, extra)

    print("")  # newline after progress

    global_result = EpisodeResult(
        reward=reward_total / n_episodes,
        gmv=gmv_total / n_episodes,
        cm2=cm2_total / n_episodes,
        orders=orders_total / n_episodes,
    )

    segment_results: Dict[str, EpisodeResult] = {}
    for seg, (s_r, s_g, s_c, s_o, s_n) in seg_totals.items():
        if s_n > 0:
            segment_results[seg] = EpisodeResult(
                reward=s_r / s_n,
                gmv=s_g / s_n,
                cm2=s_c / s_n,
                orders=s_o / s_n,
            )
    diagnostics = {
        "template_counts": template_counts.tolist(),
        "template_freqs": (template_counts / max(n_episodes, 1)).tolist(),
    }

    return global_result, segment_results, diagnostics


def _run_best_static_with_segments(
    *,
    cfg: SimulatorConfig,
    products,
    template: BoostTemplate,
    n_episodes: int,
    seed: int,
) -> Tuple[EpisodeResult, Dict[str, EpisodeResult]]:
    """Run the best static template and aggregate per-segment statistics."""
    rng = np.random.default_rng(seed)

    reward_total = 0.0
    gmv_total = 0.0
    cm2_total = 0.0
    orders_total = 0.0

    seg_totals: Dict[str, Tuple[float, float, float, float, int]] = {}

    progress_interval = max(1, n_episodes // 50)

    for episode_idx in range(1, n_episodes + 1):
        user = sample_user(config=cfg, rng=rng)
        query = sample_query(user=user, config=cfg, rng=rng)

        episode = _simulate_episode_for_template(
            template=template,
            cfg=cfg,
            user=user,
            query=query,
            products=products,
            rng=rng,
            base_scores=None,
        )

        reward_total += episode.reward
        gmv_total += episode.gmv
        cm2_total += episode.cm2
        orders_total += episode.orders

        seg_key = user.segment
        s_r, s_g, s_c, s_o, s_n = seg_totals.get(seg_key, (0.0, 0.0, 0.0, 0.0, 0))
        seg_totals[seg_key] = (
            s_r + episode.reward,
            s_g + episode.gmv,
            s_c + episode.cm2,
            s_o + episode.orders,
            s_n + 1,
        )
        if (
            episode_idx == 1
            or episode_idx % progress_interval == 0
            or episode_idx == n_episodes
        ):
            avg_reward = reward_total / episode_idx
            extra = f"avg reward {avg_reward:,.2f}"
            _progress("  Static (best) segment stats", episode_idx, n_episodes, extra)

    print("")  # newline after progress

    global_result = EpisodeResult(
        reward=reward_total / n_episodes,
        gmv=gmv_total / n_episodes,
        cm2=cm2_total / n_episodes,
        orders=orders_total / n_episodes,
    )

    segment_results: Dict[str, EpisodeResult] = {}
    for seg, (s_r, s_g, s_c, s_o, s_n) in seg_totals.items():
        if s_n > 0:
            segment_results[seg] = EpisodeResult(
                reward=s_r / s_n,
                gmv=s_g / s_n,
                cm2=s_c / s_n,
                orders=s_o / s_n,
            )

    return global_result, segment_results


def run_template_bandits_experiment(
    *,
    cfg: SimulatorConfig,
    products: List[Product],
    n_static: int,
    n_bandit: int,
    feature_mode: str,
    base_seed: int,
) -> Dict[str, Any]:
    """Core experiment: static baselines + LinUCB + Thompson Sampling.

    This is the single source of truth for Chapter 6 experiments.
    It is used by the CLI and by chapter-specific scripts.
    """
    stats = compute_catalog_stats(products)
    templates = create_standard_templates(stats, a_max=5.0)

    print(f"\nRunning static template baselines for {n_static} episodes...")
    static_results = _run_static_templates(
        cfg=cfg,
        products=products,
        templates=templates,
        n_episodes=n_static,
        seed=base_seed,
    )

    best_static_id = max(static_results, key=lambda tid: static_results[tid].reward)
    best_template = templates[best_static_id]
    best_static = static_results[best_static_id]

    print(
        f"\nBest static template: ID={best_static_id} ({best_template.name}) "
        f"with avg reward={best_static.reward:.2f}, GMV={best_static.gmv:.2f}, "
        f"CM2={best_static.cm2:.2f}"
    )

    print(
        f"\nRunning LinUCB with features={feature_mode} for "
        f"{n_bandit} episodes..."
    )
    linucb_global, linucb_seg, linucb_diag = _run_bandit_policy(
        cfg=cfg,
        products=products,
        templates=templates,
        n_episodes=n_bandit,
        seed=base_seed + 1,
        policy_type="linucb",
        feature_mode=feature_mode,
    )

    print(
        f"Running Thompson Sampling with features={feature_mode} for "
        f"{n_bandit} episodes..."
    )
    ts_global, ts_seg, ts_diag = _run_bandit_policy(
        cfg=cfg,
        products=products,
        templates=templates,
        n_episodes=n_bandit,
        seed=base_seed + 2,
        policy_type="ts",
        feature_mode=feature_mode,
    )

    static_best_global, static_best_seg = _run_best_static_with_segments(
        cfg=cfg,
        products=products,
        template=best_template,
        n_episodes=n_bandit,
        seed=base_seed + 3,
    )

    return {
        "config": {
            "seed": base_seed,
            "n_static": n_static,
            "n_bandit": n_bandit,
            "feature_mode": feature_mode,
            "feature_dim": 7 if feature_mode == "simple" else 17,
        },
        "templates": [
            {"id": t.id, "name": t.name, "description": t.description}
            for t in templates
        ],
        "static_results": {
            tid: {
                "reward": res.reward,
                "gmv": res.gmv,
                "cm2": res.cm2,
                "orders": res.orders,
            }
            for tid, res in static_results.items()
        },
        "static_best": {
            "id": best_static_id,
            "name": best_template.name,
            "result": {
                "reward": best_static.reward,
                "gmv": best_static.gmv,
                "cm2": best_static.cm2,
                "orders": best_static.orders,
            },
            "segments": {
                seg: {
                    "reward": res.reward,
                    "gmv": res.gmv,
                    "cm2": res.cm2,
                    "orders": res.orders,
                }
                for seg, res in static_best_seg.items()
            },
        },
        "linucb": {
            "global": {
                "reward": linucb_global.reward,
                "gmv": linucb_global.gmv,
                "cm2": linucb_global.cm2,
                "orders": linucb_global.orders,
            },
            "segments": {
                seg: {
                    "reward": res.reward,
                    "gmv": res.gmv,
                    "cm2": res.cm2,
                    "orders": res.orders,
                }
                for seg, res in linucb_seg.items()
            },
            "diagnostics": linucb_diag,
        },
        "ts": {
            "global": {
                "reward": ts_global.reward,
                "gmv": ts_global.gmv,
                "cm2": ts_global.cm2,
                "orders": ts_global.orders,
            },
            "segments": {
                seg: {
                    "reward": res.reward,
                    "gmv": res.gmv,
                    "cm2": res.cm2,
                    "orders": res.orders,
                }
                for seg, res in ts_seg.items()
            },
            "diagnostics": ts_diag,
        },
    }


def main() -> None:
    """CLI entry point for template bandit experiments."""
    args = _parse_args()

    def _resolve(value: int | None, fallback: int) -> int:
        if value is None:
            return fallback
        if value <= 0:
            raise ValueError("Episode counts must be positive.")
        return value

    shared = args.n_episodes
    static_episodes = _resolve(
        args.n_static, _resolve(shared, DEFAULT_EPISODES)
    )
    bandit_episodes = _resolve(
        args.n_bandit, _resolve(shared, DEFAULT_EPISODES)
    )

    print("\n" + "=" * 80)
    print("CHAPTER 6 — TEMPLATE BANDITS DEMONSTRATION")
    print("=" * 80)
    print(
        f"\nExperiment horizons: static={static_episodes:,} episodes, "
        f"bandits={bandit_episodes:,} episodes."
    )
    print(f"Feature mode: {args.features!r}")

    # Configuration and world
    cfg = SimulatorConfig()
    rng = np.random.default_rng(cfg.seed)

    print(f"\nGenerating catalog with {cfg.catalog.n_products:,} products...")
    products = catalog_module.generate_catalog(cfg.catalog, rng)

    base_seed = 2025_0601

    results = run_template_bandits_experiment(
        cfg=cfg,
        products=products,
        n_static=static_episodes,
        n_bandit=bandit_episodes,
        feature_mode=args.features,
        base_seed=base_seed,
    )

    templates_info = results["templates"]
    static_results = results["static_results"]
    static_best_info = results["static_best"]
    linucb_info = results["linucb"]
    ts_info = results["ts"]

    def pct(delta: float, base: float) -> float:
        return 100.0 * delta / base if base != 0.0 else 0.0

    print("\nStatic templates (per-episode averages):")
    if args.show_volume:
        print(
            f"{'ID':>2s}  {'Template':15s}  {'Reward':>10s}  "
            f"{'GMV':>10s}  {'CM2':>10s}  {'Orders':>10s}"
        )
    else:
        print(
            f"{'ID':>2s}  {'Template':15s}  {'Reward':>10s}  "
            f"{'GMV':>10s}  {'CM2':>10s}"
        )
    for t in templates_info:
        tid = t["id"]
        name = t["name"]
        res = static_results[tid]
        if args.show_volume:
            print(
                f"{tid:2d}  {name:15s}  "
                f"{res['reward']:10.2f}  {res['gmv']:10.2f}  "
                f"{res['cm2']:10.2f}  {res['orders']:10.2f}"
            )
        else:
            print(
                f"{tid:2d}  {name:15s}  "
                f"{res['reward']:10.2f}  {res['gmv']:10.2f}  "
                f"{res['cm2']:10.2f}"
            )

    best_static = static_best_info["result"]
    best_template_name = static_best_info["name"]

    def pct(delta: float, base: float) -> float:
        return 100.0 * delta / base if base != 0.0 else 0.0

    print("\nSummary (per-episode averages):")
    if args.show_volume:
        print(
            f"{'Policy':18s}  {'Reward':>10s}  {'GMV':>10s}  {'CM2':>10s}  {'Orders':>10s}  {'ΔGMV vs static':>14s}"
        )
    else:
        print(f"{'Policy':18s}  {'Reward':>10s}  {'GMV':>10s}  {'CM2':>10s}  {'ΔGMV vs static':>14s}")
    for name, res in [
        (f"Static-{best_template_name}", best_static),
        ("LinUCB", linucb_info["global"]),
        ("ThompsonSampling", ts_info["global"]),
    ]:
        delta_gmv = res["gmv"] - best_static["gmv"]
        if args.show_volume:
            print(
                f"{name:18s}  {res['reward']:10.2f}  {res['gmv']:10.2f}  "
                f"{res['cm2']:10.2f}  {res['orders']:10.2f}  "
                f"{pct(delta_gmv, best_static['gmv']):+13.2f}%"
            )
        else:
            print(
                f"{name:18s}  {res['reward']:10.2f}  {res['gmv']:10.2f}  "
                f"{res['cm2']:10.2f}  "
                f"{pct(delta_gmv, best_static['gmv']):+13.2f}%"
            )

    # Per-segment comparison
    if args.show_volume:
        print("\nPer-segment GMV & Orders (static best vs bandits):")
        print(
            f"{'Segment':15s}  {'Static GMV':>10s}  {'LinUCB GMV':>10s}  "
            f"{'TS GMV':>10s}  {'Static Orders':>14s}  {'LinUCB Orders':>14s}  "
            f"{'TS Orders':>11s}  {'Lin GMV Δ%':>12s}  {'TS GMV Δ%':>11s}  "
            f"{'Lin Orders Δ%':>15s}  {'TS Orders Δ%':>14s}"
        )
    else:
        print("\nPer-segment GMV (static best vs bandits):")
        print(
            f"{'Segment':15s}  {'Static GMV':>10s}  {'LinUCB GMV':>10s}  "
            f"{'TS GMV':>10s}  {'LinUCB Δ%':>11s}  {'TS Δ%':>8s}"
        )

    static_best_global = EpisodeResult(
        reward=best_static["reward"],
        gmv=best_static["gmv"],
        cm2=best_static["cm2"],
        orders=best_static["orders"],
    )
    static_seg_results = {
        seg: EpisodeResult(
            reward=metrics["reward"],
            gmv=metrics["gmv"],
            cm2=metrics["cm2"],
            orders=metrics["orders"],
        )
        for seg, metrics in static_best_info["segments"].items()
    }
    linucb_seg_results = {
        seg: EpisodeResult(
            reward=metrics["reward"],
            gmv=metrics["gmv"],
            cm2=metrics["cm2"],
            orders=metrics["orders"],
        )
        for seg, metrics in linucb_info["segments"].items()
    }
    ts_seg_results = {
        seg: EpisodeResult(
            reward=metrics["reward"],
            gmv=metrics["gmv"],
            cm2=metrics["cm2"],
            orders=metrics["orders"],
        )
        for seg, metrics in ts_info["segments"].items()
    }

    for seg in cfg.users.segments:
        s = static_seg_results.get(seg, static_best_global)
        l = linucb_seg_results.get(seg, static_best_global)
        t = ts_seg_results.get(seg, static_best_global)
        lin_gmv_delta = pct(l.gmv - s.gmv, s.gmv)
        ts_gmv_delta = pct(t.gmv - s.gmv, s.gmv)
        if args.show_volume:
            lin_orders_delta = pct(l.orders - s.orders, s.orders) if s.orders else 0.0
            ts_orders_delta = pct(t.orders - s.orders, s.orders) if s.orders else 0.0
            print(
                f"{seg:15s}  {s.gmv:10.2f}  {l.gmv:10.2f}  {t.gmv:10.2f}  "
                f"{s.orders:14.2f}  {l.orders:14.2f}  {t.orders:11.2f}  "
                f"{lin_gmv_delta:+12.2f}%  {ts_gmv_delta:+11.2f}%  "
                f"{lin_orders_delta:+15.2f}%  {ts_orders_delta:+14.2f}%"
            )
        else:
            print(
                f"{seg:15s}  {s.gmv:10.2f}  {l.gmv:10.2f}  {t.gmv:10.2f}  "
                f"{lin_gmv_delta:+10.2f}%  {ts_gmv_delta:+7.2f}%"
            )

    print("\nNotes:")
    print(
        "- This demonstration can use either a simple context feature map "
        "(segment + query type) or a richer feature set with catalog aggregates."
    )
    print(
        "- In many runs, bandits with simple features underperform strong static "
        "templates; richer features typically reduce this gap, revealing when "
        "linear contextual bandits are appropriate."
    )
    print("\nFor theory and detailed diagnostics, see:")
    print("  - docs/book/drafts/ch06/discrete_template_bandits.md")
    print("  - docs/book/drafts/ch06/exercises_labs.md")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
