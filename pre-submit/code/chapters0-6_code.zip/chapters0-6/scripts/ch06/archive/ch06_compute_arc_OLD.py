#!/usr/bin/env python
"""Chapter 6 compute arc: simple features → failure, rich features → improvement.

This script runs the complete experimental narrative for Chapter 6:

1. Simple features experiment (demonstrates failure of linear contextual bandits)
2. Rich features experiment (shows improvement with better context)
3. Saves JSON summaries for reproducibility
4. Optionally generates figures for the chapter

Usage
-----
python scripts/ch06/ch06_compute_arc.py \\
    --n-static 2000 \\
    --n-bandit 20000 \\
    --base-seed 2025_0601 \\
    --out-dir docs/book/drafts/ch06/data
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from zoosim.core.config import SimulatorConfig
from zoosim.world import catalog as catalog_module

from template_bandits_demo import run_template_bandits_experiment


def main() -> None:
    """Run the Chapter 6 compute arc."""
    parser = argparse.ArgumentParser(
        description="Chapter 6 compute arc: simple → rich features"
    )
    parser.add_argument(
        "--n-static",
        type=int,
        default=2000,
        help="Episodes for static template evaluation.",
    )
    parser.add_argument(
        "--n-bandit",
        type=int,
        default=20000,
        help="Episodes for bandit training.",
    )
    parser.add_argument(
        "--base-seed",
        type=int,
        default=2025_0601,
        help="Base random seed for reproducibility.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("docs/book/drafts/ch06/data"),
        help="Output directory for JSON summaries.",
    )
    args = parser.parse_args()

    # Create output directories
    args.out_dir.mkdir(parents=True, exist_ok=True)
    figures_dir = args.out_dir.parent / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("CHAPTER 6 — COMPUTE ARC: SIMPLE → RICH FEATURES")
    print("=" * 80)
    print("\nConfig:")
    print(f"  Static episodes:  {args.n_static:,}")
    print(f"  Bandit episodes:  {args.n_bandit:,}")
    print(f"  Base seed:        {args.base_seed}")
    print(f"  Output dir:       {args.out_dir}")

    # Build world ONCE (same catalog for both experiments)
    print("\nGenerating world...")
    cfg = SimulatorConfig(seed=args.base_seed)
    rng = np.random.default_rng(args.base_seed)
    products = catalog_module.generate_catalog(cfg.catalog, rng)
    print(f"  Catalog:  {len(products):,} products")
    print(f"  Segments: {cfg.users.segments}")
    print(f"  Queries:  {cfg.queries.query_types}")

    # ------------------------------------------------------------------
    # Experiment 1: Simple features (failure)
    # ------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("EXPERIMENT 1: SIMPLE FEATURES (Segment + Query Type)")
    print("=" * 80)
    print("Hypothesis: Linear contextual bandits should beat static baselines.")
    print("Context: φ_simple(x) = [segment_onehot, query_onehot] (7 dims)")
    print()

    simple_results = run_template_bandits_experiment(
        cfg=cfg,
        products=products,
        n_static=args.n_static,
        n_bandit=args.n_bandit,
        feature_mode="simple",
        base_seed=args.base_seed,
    )

    simple_json = args.out_dir / "template_bandits_simple_summary.json"
    with open(simple_json, "w", encoding="utf-8") as f:
        json.dump(simple_results, f, indent=2)
    print(f"\n✓ Saved: {simple_json}")

    static_gmv = simple_results["static_best"]["result"]["gmv"]
    linucb_gmv = simple_results["linucb"]["global"]["gmv"]
    ts_gmv = simple_results["ts"]["global"]["gmv"]

    print("\nRESULTS (Simple Features):")
    print(f"  Static (best):  GMV = {static_gmv:.2f}")
    print(
        f"  LinUCB:         GMV = {linucb_gmv:.2f}  "
        f"({100 * (linucb_gmv / static_gmv - 1):+.1f}%)"
    )
    print(
        f"  TS:             GMV = {ts_gmv:.2f}  "
        f"({100 * (ts_gmv / static_gmv - 1):+.1f}%)"
    )

    if linucb_gmv < static_gmv * 0.9:
        print("\n⚠️  BANDITS UNDERPERFORM STATIC (expected for pedagogical arc!)")

    # ------------------------------------------------------------------
    # Experiment 2: Rich features (improvement)
    # ------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("EXPERIMENT 2: RICH FEATURES (Full Product Aggregates)")
    print("=" * 80)
    print("Hypothesis: Rich features should improve bandit performance.")
    print(
        "Context: φ_rich(x) = [segment, query, user_prefs, price, margin, ...] (17 dims)"
    )
    print()

    rich_results = run_template_bandits_experiment(
        cfg=cfg,
        products=products,
        n_static=args.n_static,
        n_bandit=args.n_bandit,
        feature_mode="rich",
        base_seed=args.base_seed,
    )

    rich_json = args.out_dir / "template_bandits_rich_summary.json"
    with open(rich_json, "w", encoding="utf-8") as f:
        json.dump(rich_results, f, indent=2)
    print(f"\n✓ Saved: {rich_json}")

    rich_linucb_gmv = rich_results["linucb"]["global"]["gmv"]
    rich_ts_gmv = rich_results["ts"]["global"]["gmv"]

    print("\nRESULTS (Rich Features):")
    print(f"  Static (best):  GMV = {static_gmv:.2f}  (same world)")
    print(
        f"  LinUCB:         GMV = {rich_linucb_gmv:.2f}  "
        f"({100 * (rich_linucb_gmv / static_gmv - 1):+.1f}%)"
    )
    print(
        f"  TS:             GMV = {rich_ts_gmv:.2f}  "
        f"({100 * (rich_ts_gmv / static_gmv - 1):+.1f}%)"
    )

    linucb_improvement = rich_linucb_gmv - linucb_gmv
    ts_improvement = rich_ts_gmv - ts_gmv

    print("\nIMPROVEMENT (Rich vs Simple):")
    print(
        f"  LinUCB:  {linucb_improvement:+.2f} GMV  "
        f"({100 * linucb_improvement / max(linucb_gmv, 1e-8):+.1f}%)"
    )
    print(
        f"  TS:      {ts_improvement:+.2f} GMV  "
        f"({100 * ts_improvement / max(ts_gmv, 1e-8):+.1f}%)"
    )

    if rich_linucb_gmv > linucb_gmv:
        print("\n✓ RICH FEATURES IMPROVE PERFORMANCE (as expected!)")

    # ------------------------------------------------------------------
    # Figures
    # ------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("GENERATING FIGURES")
    print("=" * 80)

    try:
        from plot_results import (  # type: ignore import-not-found
            plot_segment_comparison,
            plot_template_frequencies,
        )

        print("\nPlot 1: Segment GMV comparison...")
        plot_segment_comparison(simple_json, rich_json, figures_dir)

        print("Plot 2: Template selection frequencies (simple features)...")
        plot_template_frequencies(simple_json, figures_dir, suffix="simple")

        print("Plot 3: Template selection frequencies (rich features)...")
        plot_template_frequencies(rich_json, figures_dir, suffix="rich")

    except ImportError as exc:
        print(f"\n⚠️  Plotting skipped (plot_results.py not available): {exc}")
        print("    Implement scripts/ch06/plot_results.py to enable figure generation.")

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("\nAll artifacts saved to:")
    print(f"  Data:    {args.out_dir}")
    print(f"  Figures: {figures_dir}")
    print("\nRegenerate with:")
    print("  python scripts/ch06/ch06_compute_arc.py \\")
    print(f"      --n-static {args.n_static} \\")
    print(f"      --n-bandit {args.n_bandit} \\")
    print(f"      --base-seed {args.base_seed}")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()

