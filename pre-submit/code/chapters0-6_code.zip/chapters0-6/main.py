def main():
    print("Hello from rl-search-from-scratch!")


if __name__ == "__main__":
    main()
